The XML Schema Documents for the OpenGIS� Web Services (OWS) 
Implementation Specification version 1.0.0 [OGC 05-008] that are modified for use in WCS 1.1 have been moved into the WCS/1.1 directory.

Arliss Whiteside, 2006-07-24

