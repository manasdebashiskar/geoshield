﻿--
-- PostgreSQL database dump
--

-- Started on 2010-11-18

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

CREATE TABLE applications (
    id_aps integer NOT NULL,
    name_aps character varying(50) NOT NULL,
    desc_aps text,
    path_aps character varying(50),
    port_aps integer DEFAULT 80 NOT NULL,
    host_aps character varying(100) NOT NULL,
    vpath_aps character varying(20),
    is_public_aps boolean DEFAULT true,
    is_hidden_aps boolean DEFAULT false,
    home_aps character varying(60)
);


COMMENT ON COLUMN applications.name_aps IS 'Name (identifier) of the application';
COMMENT ON COLUMN applications.desc_aps IS 'Description of the application';
COMMENT ON COLUMN applications.path_aps IS 'Application path';
COMMENT ON COLUMN applications.port_aps IS 'Port connection';
COMMENT ON COLUMN applications.host_aps IS 'Application URL';
COMMENT ON COLUMN applications.vpath_aps IS 'Application virtual path that user can see';
COMMENT ON COLUMN applications.is_public_aps IS 'Define if the application is open to not autheticated users';
COMMENT ON COLUMN applications.home_aps IS 'File name with parameters of the web apps home page';

CREATE SEQUENCE applications_id_aps_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER SEQUENCE applications_id_aps_seq OWNED BY applications.id_aps;

SELECT pg_catalog.setval('applications_id_aps_seq', 11, true);


CREATE TABLE users (
    id_usr integer NOT NULL,
    name_usr character varying(20) NOT NULL,
    psw_usr character varying(20),
    first_name_usr character varying(50),
    last_name_usr character varying(50),
    email_usr character varying(100),
    office_usr character varying(100),
    tel_usr character varying(20),
    fax_usr character varying(20),
    address_usr text,
    is_active_usr boolean DEFAULT true
);

CREATE VIEW auth_header AS
    SELECT users.id_usr, (((users.name_usr)::text || ':'::text) || (users.psw_usr)::text) AS auth FROM users;

CREATE TABLE groups (
    id_grp integer NOT NULL,
    name_grp character varying(100)
);

CREATE SEQUENCE groups_id_grp_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

ALTER SEQUENCE groups_id_grp_seq OWNED BY groups.id_grp;

SELECT pg_catalog.setval('groups_id_grp_seq', 8, true);

CREATE TABLE groups_users (
    id_gus integer NOT NULL,
    id_grp_fk integer NOT NULL,
    id_usr_fk integer NOT NULL,
    expiration_gus date,
    invoice_gus character varying(100)
);

CREATE SEQUENCE groups_users_id_gus_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

ALTER SEQUENCE groups_users_id_gus_seq OWNED BY groups_users.id_gus;

SELECT pg_catalog.setval('groups_users_id_gus_seq', 1, true);

CREATE TABLE grp_aps (
    id_gra integer NOT NULL,
    id_grp_fk bigint NOT NULL,
    id_aps_fk bigint NOT NULL
);

CREATE SEQUENCE grp_aps_id_gra_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

ALTER SEQUENCE grp_aps_id_gra_seq OWNED BY grp_aps.id_gra;

SELECT pg_catalog.setval('grp_aps_id_gra_seq', 2, true);

CREATE TABLE layers (
    id_lay integer NOT NULL,
    id_sur_fk integer NOT NULL,
    name_lay character varying(50) NOT NULL,
    geom_lay character varying(30) NOT NULL,
    ns_lay character varying(20),
    ns_url_lay character varying(64)
);

CREATE SEQUENCE layers_id_lay_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

ALTER SEQUENCE layers_id_lay_seq OWNED BY layers.id_lay;

SELECT pg_catalog.setval('layers_id_lay_seq', 112, true);

CREATE TABLE layers_permissions (
    id_lpr integer NOT NULL,
    id_lay_fk integer NOT NULL,
    id_grp_fk integer NOT NULL,
    filter_lpr text,
    priority_lpr integer DEFAULT 4 NOT NULL
);

CREATE SEQUENCE layers_permissions_id_lpr_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

ALTER SEQUENCE layers_permissions_id_lpr_seq OWNED BY layers_permissions.id_lpr;

SELECT pg_catalog.setval('layers_permissions_id_lpr_seq', 173, true);

CREATE TABLE requests (
    id_req integer NOT NULL,
    id_srv_fk integer NOT NULL,
    name_req character varying(20) NOT NULL
);

CREATE SEQUENCE requests_id_req_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

ALTER SEQUENCE requests_id_req_seq OWNED BY requests.id_req;

SELECT pg_catalog.setval('requests_id_req_seq', 5, true);

CREATE TABLE services (
    id_srv integer NOT NULL,
    name_srv character varying(20)
);

CREATE SEQUENCE services_id_srv_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

ALTER SEQUENCE services_id_srv_seq OWNED BY services.id_srv;

SELECT pg_catalog.setval('services_id_srv_seq', 1, false);

CREATE TABLE services_permissions (
    id_spr integer NOT NULL,
    id_sur_fk integer NOT NULL,
    id_grp_fk integer NOT NULL
);

CREATE SEQUENCE services_permissions_id_spr_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

ALTER SEQUENCE services_permissions_id_spr_seq OWNED BY services_permissions.id_spr;

SELECT pg_catalog.setval('services_permissions_id_spr_seq', 15, true);

CREATE TABLE services_urls (
    id_sur integer NOT NULL,
    id_srv_fk integer NOT NULL,
    path_sur character varying(15) NOT NULL,
    url_sur character varying(100) NOT NULL,
    usr_sur character varying(50),
    psw_sur character varying(50)
);

CREATE SEQUENCE services_urls_id_sur_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

ALTER SEQUENCE services_urls_id_sur_seq OWNED BY services_urls.id_sur;

SELECT pg_catalog.setval('services_urls_id_sur_seq', 6, true);

CREATE TABLE spr_req (
    id_sre integer NOT NULL,
    id_req_fk integer NOT NULL,
    id_spr_fk integer NOT NULL
);

CREATE SEQUENCE spr_req_id_sre_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

ALTER SEQUENCE spr_req_id_sre_seq OWNED BY spr_req.id_sre;

SELECT pg_catalog.setval('spr_req_id_sre_seq', 45, true);

CREATE SEQUENCE users_id_usr_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;

ALTER SEQUENCE users_id_usr_seq OWNED BY users.id_usr;

SELECT pg_catalog.setval('users_id_usr_seq', 288, true);

ALTER TABLE applications ALTER COLUMN id_aps SET DEFAULT nextval('applications_id_aps_seq'::regclass);

ALTER TABLE groups ALTER COLUMN id_grp SET DEFAULT nextval('groups_id_grp_seq'::regclass);

ALTER TABLE groups_users ALTER COLUMN id_gus SET DEFAULT nextval('groups_users_id_gus_seq'::regclass);

ALTER TABLE grp_aps ALTER COLUMN id_gra SET DEFAULT nextval('grp_aps_id_gra_seq'::regclass);

ALTER TABLE layers ALTER COLUMN id_lay SET DEFAULT nextval('layers_id_lay_seq'::regclass);

ALTER TABLE layers_permissions ALTER COLUMN id_lpr SET DEFAULT nextval('layers_permissions_id_lpr_seq'::regclass);

ALTER TABLE requests ALTER COLUMN id_req SET DEFAULT nextval('requests_id_req_seq'::regclass);

ALTER TABLE services ALTER COLUMN id_srv SET DEFAULT nextval('services_id_srv_seq'::regclass);

ALTER TABLE services_permissions ALTER COLUMN id_spr SET DEFAULT nextval('services_permissions_id_spr_seq'::regclass);

ALTER TABLE services_urls ALTER COLUMN id_sur SET DEFAULT nextval('services_urls_id_sur_seq'::regclass);

ALTER TABLE spr_req ALTER COLUMN id_sre SET DEFAULT nextval('spr_req_id_sre_seq'::regclass);

ALTER TABLE users ALTER COLUMN id_usr SET DEFAULT nextval('users_id_usr_seq'::regclass);


INSERT INTO groups (id_grp, name_grp) VALUES (1, 'demo');

INSERT INTO groups_users (id_gus, id_grp_fk, id_usr_fk, expiration_gus, invoice_gus) VALUES (1, 1, 1, NULL, NULL);

INSERT INTO layers (id_lay, id_sur_fk, name_lay, geom_lay, ns_lay, ns_url_lay) VALUES (109, 4, 'topp:tasmania_water_bodies', 'the_geom', 'topp', 'http://www.openplans.org/topp');
INSERT INTO layers (id_lay, id_sur_fk, name_lay, geom_lay, ns_lay, ns_url_lay) VALUES (110, 4, 'topp:tasmania_state_boundaries', 'the_geom', 'topp', 'http://www.openplans.org/topp');
INSERT INTO layers (id_lay, id_sur_fk, name_lay, geom_lay, ns_lay, ns_url_lay) VALUES (111, 4, 'topp:tasmania_cities', 'the_geom', 'topp', 'http://www.openplans.org/topp');
INSERT INTO layers (id_lay, id_sur_fk, name_lay, geom_lay, ns_lay, ns_url_lay) VALUES (112, 6, 'topp:tasmania_cities', 'the_geom', 'topp', 'http://www.openplans.org/topp');
INSERT INTO layers (id_lay, id_sur_fk, name_lay, geom_lay, ns_lay, ns_url_lay) VALUES (108, 4, 'topp:tasmania_roads', 'the_geom', 'topp', 'http://www.openplans.org/topp');

INSERT INTO layers_permissions (id_lpr, id_lay_fk, id_grp_fk, filter_lpr, priority_lpr) VALUES (171, 111, 1, 'INCLUDE', 4);
INSERT INTO layers_permissions (id_lpr, id_lay_fk, id_grp_fk, filter_lpr, priority_lpr) VALUES (172, 110, 1, 'INCLUDE', 4);
INSERT INTO layers_permissions (id_lpr, id_lay_fk, id_grp_fk, filter_lpr, priority_lpr) VALUES (169, 108, 1, 'TYPE=''road''', 4);
INSERT INTO layers_permissions (id_lpr, id_lay_fk, id_grp_fk, filter_lpr, priority_lpr) VALUES (170, 109, 1, 'BBOX(the_geom, 145.8, -43.2, 146.5, -42.5)', 4);
INSERT INTO layers_permissions (id_lpr, id_lay_fk, id_grp_fk, filter_lpr, priority_lpr) VALUES (173, 112, 1, 'CITY_NAME=''Hobart''', 4);

INSERT INTO requests (id_req, id_srv_fk, name_req) VALUES (1, 1, 'getcapabilities');
INSERT INTO requests (id_req, id_srv_fk, name_req) VALUES (2, 1, 'getmap');
INSERT INTO requests (id_req, id_srv_fk, name_req) VALUES (3, 1, 'getfeatureinfo');
INSERT INTO requests (id_req, id_srv_fk, name_req) VALUES (4, 2, 'getcapabilities');
INSERT INTO requests (id_req, id_srv_fk, name_req) VALUES (5, 1, 'getLegendGraphic');
INSERT INTO requests (id_req, id_srv_fk, name_req) VALUES (6, 2, 'describeFeatureType');
INSERT INTO requests (id_req, id_srv_fk, name_req) VALUES (7, 2, 'getFeature');
INSERT INTO requests (id_req, id_srv_fk, name_req) VALUES (8, 2, 'getGmlObject');

INSERT INTO services (id_srv, name_srv) VALUES (1, 'WMS');
INSERT INTO services (id_srv, name_srv) VALUES (2, 'WFS');


INSERT INTO services_permissions (id_spr, id_sur_fk, id_grp_fk) VALUES (14, 6, 1);
INSERT INTO services_permissions (id_spr, id_sur_fk, id_grp_fk) VALUES (15, 4, 1);

INSERT INTO services_urls (id_sur, id_srv_fk, path_sur, url_sur, usr_sur, psw_sur) VALUES (4, 1, '/demo', 'http://localhost:80/geoserver/wms', NULL, NULL);
INSERT INTO services_urls (id_sur, id_srv_fk, path_sur, url_sur, usr_sur, psw_sur) VALUES (6, 2, '/demo', 'http://localhost:80/geoserver/wfs', 'admin', 'geoserver');

INSERT INTO spr_req (id_sre, id_req_fk, id_spr_fk) VALUES (38, 4, 14);
INSERT INTO spr_req (id_sre, id_req_fk, id_spr_fk) VALUES (39, 7, 14);
INSERT INTO spr_req (id_sre, id_req_fk, id_spr_fk) VALUES (40, 8, 14);
INSERT INTO spr_req (id_sre, id_req_fk, id_spr_fk) VALUES (41, 6, 14);
INSERT INTO spr_req (id_sre, id_req_fk, id_spr_fk) VALUES (42, 1, 15);
INSERT INTO spr_req (id_sre, id_req_fk, id_spr_fk) VALUES (43, 5, 15);
INSERT INTO spr_req (id_sre, id_req_fk, id_spr_fk) VALUES (44, 3, 15);
INSERT INTO spr_req (id_sre, id_req_fk, id_spr_fk) VALUES (45, 2, 15);

INSERT INTO users (id_usr, name_usr, psw_usr, first_name_usr, last_name_usr, email_usr, office_usr, tel_usr, fax_usr, address_usr, is_active_usr) VALUES (1, 'demo', 'demo', 'John', 'Demo', 'demo@demo.com', 'Demo', '+41912345678', '+41912345679', '', true);

ALTER TABLE ONLY applications
    ADD CONSTRAINT applications_pkey PRIMARY KEY (id_aps);

ALTER TABLE ONLY groups
    ADD CONSTRAINT groups_name_grp_key UNIQUE (name_grp);

ALTER TABLE ONLY groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id_grp);

ALTER TABLE ONLY groups_users
    ADD CONSTRAINT groups_users_id_grp_fk_key UNIQUE (id_grp_fk, id_usr_fk);

ALTER TABLE ONLY groups_users
    ADD CONSTRAINT groups_users_pkey PRIMARY KEY (id_gus);

ALTER TABLE ONLY grp_aps
    ADD CONSTRAINT grp_aps_id_grp_fk_key UNIQUE (id_grp_fk, id_aps_fk);

ALTER TABLE ONLY grp_aps
    ADD CONSTRAINT grp_aps_pkey PRIMARY KEY (id_gra);

ALTER TABLE ONLY layers
    ADD CONSTRAINT lay_pkey PRIMARY KEY (id_lay);

ALTER TABLE ONLY layers
    ADD CONSTRAINT lay_uniq UNIQUE (id_sur_fk, name_lay, geom_lay);

ALTER TABLE ONLY layers_permissions
    ADD CONSTRAINT lpr_pkey PRIMARY KEY (id_lpr);

ALTER TABLE ONLY layers_permissions
    ADD CONSTRAINT lpr_uniq UNIQUE (id_lay_fk, id_grp_fk);

ALTER TABLE ONLY requests
    ADD CONSTRAINT requests_pkey PRIMARY KEY (id_req);

ALTER TABLE ONLY services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id_srv);

ALTER TABLE ONLY services_urls
    ADD CONSTRAINT services_urls_id_srv_fk_key UNIQUE (id_srv_fk, path_sur);

ALTER TABLE ONLY services_permissions
    ADD CONSTRAINT spr_pkey PRIMARY KEY (id_spr);

ALTER TABLE ONLY services_permissions
    ADD CONSTRAINT spr_uniq_sur_grp UNIQUE (id_sur_fk, id_grp_fk);

ALTER TABLE ONLY spr_req
    ADD CONSTRAINT sre_pkey PRIMARY KEY (id_sre);

ALTER TABLE ONLY spr_req
    ADD CONSTRAINT sre_uniq_req_spr UNIQUE (id_req_fk, id_spr_fk);

ALTER TABLE ONLY services_urls
    ADD CONSTRAINT sur_pkey PRIMARY KEY (id_sur);

ALTER TABLE ONLY users
    ADD CONSTRAINT users_name_usr_key UNIQUE (name_usr);

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id_usr);

ALTER TABLE ONLY groups_users
    ADD CONSTRAINT groups_users_id_grp_fk_fkey FOREIGN KEY (id_grp_fk) REFERENCES groups(id_grp) ON DELETE CASCADE;

ALTER TABLE ONLY groups_users
    ADD CONSTRAINT groups_users_id_usr_fk_fkey FOREIGN KEY (id_usr_fk) REFERENCES users(id_usr) ON DELETE CASCADE;

ALTER TABLE ONLY grp_aps
    ADD CONSTRAINT grp_aps_id_aps_fk_fkey FOREIGN KEY (id_aps_fk) REFERENCES applications(id_aps);

ALTER TABLE ONLY grp_aps
    ADD CONSTRAINT grp_aps_id_grp_fk_fkey FOREIGN KEY (id_grp_fk) REFERENCES groups(id_grp);

ALTER TABLE ONLY layers
    ADD CONSTRAINT lay_sur_fk FOREIGN KEY (id_sur_fk) REFERENCES services_urls(id_sur);

ALTER TABLE ONLY layers_permissions
    ADD CONSTRAINT layers_permissions_id_grp_fk_fkey FOREIGN KEY (id_grp_fk) REFERENCES groups(id_grp) ON DELETE CASCADE;

ALTER TABLE ONLY layers_permissions
    ADD CONSTRAINT layers_permissions_id_lay_fk_fkey FOREIGN KEY (id_lay_fk) REFERENCES layers(id_lay) ON DELETE CASCADE;

ALTER TABLE ONLY requests
    ADD CONSTRAINT req_srv_fk FOREIGN KEY (id_srv_fk) REFERENCES services(id_srv);

ALTER TABLE ONLY services_permissions
    ADD CONSTRAINT services_permissions_id_grp_fk_fkey FOREIGN KEY (id_grp_fk) REFERENCES groups(id_grp) ON DELETE CASCADE;

ALTER TABLE ONLY services_permissions
    ADD CONSTRAINT services_permissions_id_sur_fk_fkey FOREIGN KEY (id_sur_fk) REFERENCES services_urls(id_sur) ON DELETE CASCADE;

ALTER TABLE ONLY spr_req
    ADD CONSTRAINT spr_req_id_req_fk_fkey FOREIGN KEY (id_req_fk) REFERENCES requests(id_req) ON DELETE CASCADE;

ALTER TABLE ONLY spr_req
    ADD CONSTRAINT spr_req_id_spr_fk_fkey FOREIGN KEY (id_spr_fk) REFERENCES services_permissions(id_spr) ON DELETE CASCADE;

ALTER TABLE ONLY services_urls
    ADD CONSTRAINT sur_srv_fk FOREIGN KEY (id_srv_fk) REFERENCES services(id_srv);

